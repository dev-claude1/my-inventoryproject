import { useState } from "react";
import {
  Users,
  Star,
  MousePointer2,
  Activity,
  RotateCcw,
  Code2,
  CheckCircle2,
  ArrowUpRight
} from "lucide-react";

export default function App() {
  const [visitors, setVisitors] = useState(0);
  const [favorite, setFavorite] = useState(false);
  const [highlight, setHighlight] = useState(false);
  const [eventInfo, setEventInfo] = useState({
    type: "Waiting for interaction",
    target: "—",
    currentTarget: "—",
    time: "Not yet"
  });
  const [bugDemo, setBugDemo] = useState(false);
  const [bugRuns, setBugRuns] = useState(0);

  function showEvent(event) {
    setEventInfo({
      type: event.type,
      target: event.target.tagName.toLowerCase(),
      currentTarget: event.currentTarget.tagName.toLowerCase(),
      time: new Date().toLocaleTimeString()
    });
  }

  function handleJoin(event) {
    setVisitors((count) => count + 1);
    showEvent(event);
  }

  function handleFavorite(event) {
    setFavorite((value) => !value);
    showEvent(event);
  }

  function handleMouseEnter(event) {
    setHighlight(true);
    showEvent(event);
  }

  function handleMouseLeave(event) {
    setHighlight(false);
    showEvent(event);
  }

  function resetDemo() {
    setVisitors(0);
    setFavorite(false);
    setHighlight(false);
    setEventInfo({
      type: "Waiting for interaction",
      target: "—",
      currentTarget: "—",
      time: "Not yet"
    });
    setBugDemo(false);
    setBugRuns(0);
  }

  // This function is deliberately safe for the bug demonstration:
  // it logs/counters when called, but does not update React state during render.
  function handleBugExample() {
    setBugRuns((count) => count + 1);
  }

  return (
    <main className="page-shell">
      <header className="topbar">
        <a className="brand" href="#home" aria-label="React Events Practice home">
          <span className="brand-mark"><Code2 size={21} /></span>
          <span>React<span className="brand-light">Lab</span></span>
        </a>
        <div className="topbar-tag"><span className="live-dot" /> INTERACTIVE LESSON</div>
      </header>

      <section className="hero" id="home">
        <div className="eyebrow"><span className="eyebrow-line" /> REACT FUNDAMENTALS</div>
        <h1>Events make<br /><span>things happen.</span></h1>
        <p className="hero-copy">
          Practice React event handlers with a club card, live event inspector,
          and a simple demonstration of a common onClick bug.
        </p>
        <div className="hero-meta">
          <span><CheckCircle2 size={16} /> 5 practical exercises</span>
          <span><Activity size={16} /> Live interactions</span>
        </div>
      </section>

      <section className="workspace">
        <div className="section-heading">
          <div>
            <p className="section-kicker">01 / HANDS-ON</p>
            <h2>Club card playground</h2>
            <p className="section-description">Click, double-click, or move your pointer over the card.</p>
          </div>
          <button className="reset-button" onClick={resetDemo}>
            <RotateCcw size={15} /> Reset demo
          </button>
        </div>

        <div className="playground-grid">
          <article
            className={`club-card ${highlight ? "club-card-highlight" : ""}`}
            onDoubleClick={handleFavorite}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <div className="card-topline">
              <span className="club-icon"><Users size={24} /></span>
              <span className={`status-pill ${favorite ? "status-favorite" : ""}`}>
                {favorite ? <><Star size={13} fill="currentColor" /> FAVORITE</> : "OPEN TO JOIN"}
              </span>
            </div>
            <p className="card-label">STUDENT COMMUNITY</p>
            <h3>Computer Science<br />Club</h3>
            <p className="card-description">
              Learn together, build projects, and share ideas with other curious developers.
            </p>
            <div className="visitor-row">
              <div className="avatar-stack" aria-hidden="true">
                <span>P</span><span>A</span><span>J</span>
              </div>
              <div><strong>{visitors} {visitors === 1 ? "visitor" : "visitors"}</strong><small>joined in this session</small></div>
            </div>
            <button className="join-button" onClick={handleJoin}>
              Join this club <ArrowUpRight size={17} />
            </button>
            <div className="card-hint"><MousePointer2 size={14} /> Double-click anywhere on the card to favorite it</div>
          </article>

          <aside className="event-panel">
            <div className="panel-heading">
              <span className="panel-icon"><Activity size={19} /></span>
              <div><h3>Event inspector</h3><p>Updates with every interaction</p></div>
              <span className="live-pill">LIVE</span>
            </div>
            <div className="event-main">
              <span className="field-label">EVENT.TYPE</span>
              <div className="event-value">{eventInfo.type}</div>
            </div>
            <div className="inspector-row">
              <div><span className="field-label">EVENT.TARGET</span><code>{eventInfo.target}</code></div>
              <div><span className="field-label">CURRENT TARGET</span><code>{eventInfo.currentTarget}</code></div>
            </div>
            <div className="inspector-footer">
              <span>Last interaction</span><strong>{eventInfo.time}</strong>
            </div>
            <p className="panel-note">
              <strong>Tip:</strong> <code>target</code> is where the event originated.
              <code> currentTarget</code> is the element running the handler.
            </p>
          </aside>
        </div>
      </section>

      <section className="bug-section">
        <div className="section-heading">
          <div>
            <p className="section-kicker">02 / UNDERSTAND THE BUG</p>
            <h2>When does the function run?</h2>
            <p className="section-description">Compare passing a function with calling it immediately.</p>
          </div>
        </div>

        <div className="comparison-grid">
          <article className="code-card wrong-card">
            <div className="code-card-head">
              <span className="code-status wrong-status">✕ WRONG PATTERN</span>
              <span className="code-language">JSX</span>
            </div>
            <pre><code>{'<button onClick={handleBugExample()}>\n  Click me\n</button>'}</code></pre>
            <p>Calls the function during rendering instead of waiting for a click. If that function updates state, it can cause repeated renders.</p>
          </article>
          <article className="code-card right-card">
            <div className="code-card-head">
              <span className="code-status right-status">✓ CORRECT PATTERN</span>
              <span className="code-language">JSX</span>
            </div>
            <pre><code>{'<button onClick={handleBugExample}>\n  Click me\n</button>'}</code></pre>
            <p>Passes the function to React. React runs it when the button is clicked.</p>
          </article>
        </div>

        <div className="safe-demo">
          <div>
            <h3>Try the correct pattern</h3>
            <p>This safe example calls the handler only after you click the button.</p>
          </div>
          <button className="test-button" onClick={() => setBugRuns((count) => count + 1)}>
            Test handler <ArrowUpRight size={16} />
          </button>
          <div className="run-count"><strong>{bugRuns}</strong><span>clicks</span></div>
        </div>
        <div className="code-tip">
          <span className="tip-symbol">i</span>
          <p>Need to pass an argument? Use <code>onClick={() => handle("Patrick")}</code>. The arrow function delays the call until the click.</p>
        </div>
      </section>

      <section className="quick-reference">
        <p className="section-kicker">03 / QUICK REFERENCE</p>
        <h2>Events to remember</h2>
        <div className="reference-grid">
          <div className="reference-item"><code>onClick</code><span>Single click</span></div>
          <div className="reference-item"><code>onDoubleClick</code><span>Double-click</span></div>
          <div className="reference-item"><code>onMouseEnter</code><span>Pointer enters</span></div>
          <div className="reference-item"><code>onMouseLeave</code><span>Pointer leaves</span></div>
          <div className="reference-item"><code>event.type</code><span>Event name</span></div>
          <div className="reference-item"><code>event.target</code><span>Origin element</span></div>
        </div>
      </section>

      <footer className="footer">
        <span className="brand"><span className="brand-mark"><Code2 size={18} /></span> React<span className="brand-light">Lab</span></span>
        <span>Built for learning React events · Practice by experimenting</span>
      </footer>
    </main>
  );
}
