# React Events Practice

A beginner-friendly React + Vite project for practicing:
- `onClick` and a visitor counter
- `onDoubleClick` to toggle favorite status
- `onMouseEnter` / `onMouseLeave` card highlighting
- `event.type`, `event.target`, and `event.currentTarget`
- Why `onClick={handler()}` is different from `onClick={handler}`

## Requirements
Install Node.js (LTS) from https://nodejs.org if it is not already installed.

## Run on Windows
1. Extract the ZIP file.
2. Open the extracted `react-events-practice` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL Vite shows in the terminal (usually `http://localhost:5173`).

## Create a production build
```bash
npm run build
```

Note: Google Fonts are loaded from the internet. The app itself works without them, using fallback fonts.
